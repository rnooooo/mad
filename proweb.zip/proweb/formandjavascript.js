‏<!DOCTYPE html>
‏<html lang="ar">
‏<head>
‏  <meta charset="UTF-8">
    <link rel="stylesheet" href="stylej.css">
‏  <title>اتصل بنا</title>
‏  <style>
‏    body { font-family: Arial; direction: rtl; }
‏    form { max-width: 400px; margin: auto; }
‏    input, textarea { width: 100%; padding: 10px; margin: 10px 0; }
‏    .error { color: red; }
‏  </style>
‏</head>
‏<body>

‏<h2>نموذج اتصل بنا</h2>

‏<form id="contactForm" onsubmit="return validateForm()">
‏  <input type="text" id="name" placeholder="الاسم" required>

‏  <input type="email" id="email" placeholder="البريد الإلكتروني" 
‏         pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" required>

‏  <input type="tel" id="phone" placeholder="رقم الهاتف (اختياري)" pattern="[0-9]{10}">

‏  <textarea id="message" placeholder="اكتب رسالتك هنا..." required></textarea>

‏  <p id="errorMsg" class="error"></p>

‏  <button type="submit">إرسال</button>
‏</form>

‏<script>
‏function validateForm() {
‏  const email = document.getElementById("email").value;
‏  const name = document.getElementById("name").value;
‏  const message = document.getElementById("message").value;
‏  const errorMsg = document.getElementById("errorMsg");

‏  errorMsg.textContent = "";

‏  if (name.length < 3) {
‏    errorMsg.textContent = "الاسم يجب أن يحتوي على 3 أحرف على الأقل.";
‏    return false;
  }

‏  if (!email.includes("@") || !email.includes(".")) {
‏    errorMsg.textContent = "إدخال بريد إلكتروني صحيح.";
‏    return false;
  }

‏  if (message.length < 10) {
‏    errorMsg.textContent = "الرسالة يجب أن تكون أطول.";
‏    return false;
  }

‏  alert("تم الإرسال بنجاح!");
‏  return true;
}
‏</script>

‏</body>
‏</html>